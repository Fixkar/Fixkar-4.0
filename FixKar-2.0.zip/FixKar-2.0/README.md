# 🔧 FixKar — Pakistan's #1 Roadside Vehicle Assistance App

> **جہاں گاڑی رکے، وہاں مدد پہنچے**
> *Where Your Vehicle Stops, Help Arrives*

![FixKar Banner](https://img.shields.io/badge/FixKar-Vehicle%20Assistance-FF6B00?style=for-the-badge&logo=data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTIyIDEySDJNMTIgMlYyMiIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLXdpZHRoPSIyIi8+PC9zdmc+)
![Version](https://img.shields.io/badge/Version-2.0.0-00D4AA?style=for-the-badge)
![Pakistan](https://img.shields.io/badge/Made%20For-Pakistan%20🇵🇰-1A1A2E?style=for-the-badge)

---

## 🚀 Live Demo

Open `index.html` in any browser — fully interactive app prototype!

Or deploy instantly:
- **GitHub Pages** → Settings → Pages → Deploy from main branch
- **Netlify** → Drag & drop the folder
- **Vercel** → Import GitHub repo

---

## 📱 What Is FixKar?

FixKar is a **full roadside vehicle assistance and mechanic marketplace** for Pakistan. When your car or bike breaks down anywhere, open FixKar — a certified nearby mechanic comes to you.

Think **Uber + Amazon + Foodpanda** but for vehicle repairs.

---

## ✨ Features

### For Vehicle Owners
- 🚨 **Emergency SOS** — One tap to request help instantly
- 📍 **Live Mechanic Tracking** — Watch mechanic arrive in real time
- 🔧 **16+ Service Types** — Battery, tyre, fuel, towing, engine and more
- 💳 **Multiple Payments** — JazzCash, EasyPaisa, Card, Cash, Wallet
- ⭐ **Ratings & Reviews** — Rate your mechanic after every job
- 🕐 **Scheduled Booking** — Book a mechanic in advance

### For Mechanics
- 📲 **Instant Job Alerts** — Get notified of nearby requests immediately
- 💰 **Earnings Dashboard** — Track daily, weekly, monthly income
- ⭐ **Subscription Plans** — Free, Silver, Gold, Workshop tiers
- 🗺️ **Navigation** — Google Maps turn-by-turn to customer
- 👛 **Instant Withdrawals** — Cash out to JazzCash or EasyPaisa

### Platform
- 🤖 **AI Chatbot** — 24/7 support in Urdu & English
- 🌙 **Dark Mode** — Premium dark UI by default
- 🇵🇰 **Urdu Support** — Full RTL Urdu language
- 🔐 **CNIC Verification** — All mechanics verified by admin

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML5, CSS3, Vanilla JS (prototype) |
| Mobile App | React Native (production) |
| Backend | Node.js + Express.js |
| Database | Firebase Firestore |
| Auth | Firebase Authentication |
| Maps | Google Maps API |
| Payments | JazzCash API + EasyPaisa API |
| AI | Google Gemini API |
| Hosting | Firebase Hosting / Vercel |

---

## 🚀 Quick Start

### Run the Prototype (No setup needed)
```bash
# Just open in browser
open index.html

# Or serve locally
npx serve .
```

### Full App Setup (Coming Soon)
```bash
# Clone repo
git clone https://github.com/Fixkar/FixKar-2.0.git
cd FixKar-2.0

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Fill in your API keys

# Run development server
npm run dev
```

---

## 📁 Project Structure

```
FixKar-2.0/
├── index.html              ← Complete app prototype (deploy this!)
├── src/
│   ├── screens/            ← All app screens
│   ├── components/         ← Reusable components
│   ├── services/           ← Firebase, payments, maps
│   ├── i18n/               ← English + Urdu translations
│   └── utils/              ← Helper functions
├── .env.example            ← Environment variables template
├── .gitignore              ← Protects your secrets
└── README.md               ← This file
```

---

## 💰 Revenue Model

| Stream | Details |
|--------|---------|
| Mechanic Subscriptions | Rs. 999 – Rs. 49,999/year |
| Service Commission | 15% standard, 20% emergency |
| Featured Listings | Promoted mechanic placement |
| Emergency Priority | Premium fast-response fee |

---

## 🗺️ Roadmap

- [x] App UI/UX Design
- [x] Core screens (Home, Emergency, Tracking, Payment)
- [x] Mechanic Dashboard
- [x] Subscription Plans
- [ ] Firebase Backend Integration
- [ ] JazzCash & EasyPaisa Live Payments
- [ ] Google Maps Live Tracking
- [ ] React Native Mobile App
- [ ] Admin Web Panel
- [ ] Google Play Store Launch
- [ ] Apple App Store Launch

---

## 🔒 Security

- No payment credentials stored in frontend code
- All API keys in `.env` (never committed to GitHub)
- CNIC verification for all mechanics
- End-to-end encrypted chat
- Firebase security rules enforced

---

## 📞 Support

- **WhatsApp:** +92 306 8624088
- **Email:** support@fixkar.pk
- **Website:** fixkar.pk

---

## 📄 License

Copyright © 2024 FixKar. All rights reserved.

---

*Built with ❤️ for Pakistan 🇵🇰*
